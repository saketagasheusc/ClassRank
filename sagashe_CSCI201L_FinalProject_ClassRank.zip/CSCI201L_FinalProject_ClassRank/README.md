To run:
Run Driver.java once
Then run OnePage.jsp

Must have: JDBC, org.simple (MAVEN) as jars

Changed to single page app today, caused some bugs, will resolve