CREATE DATABASE `ClassRankSchema` /*!40100 DEFAULT CHARACTER SET latin1 */;
CREATE TABLE `Course` (
  `classID` int(10) NOT NULL AUTO_INCREMENT,
  `Department` varchar(45) DEFAULT NULL,
  `ClassCode` varchar(45) DEFAULT NULL,
  `CourseName` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`classID`),
  UNIQUE KEY `classID_UNIQUE` (`classID`),
  UNIQUE KEY `ClassCode_UNIQUE` (`ClassCode`),
  UNIQUE KEY `CourseName_UNIQUE` (`CourseName`)
) ENGINE=InnoDB AUTO_INCREMENT=116870 DEFAULT CHARSET=latin1;
CREATE TABLE `Department` (
  `departmentID` int(11) NOT NULL AUTO_INCREMENT,
  `departmentCode` varchar(45) DEFAULT NULL,
  `departmentName` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`departmentID`),
  UNIQUE KEY `departmentID_UNIQUE` (`departmentID`),
  UNIQUE KEY `departmentCode_UNIQUE` (`departmentCode`)
) ENGINE=InnoDB AUTO_INCREMENT=8529 DEFAULT CHARSET=latin1;
CREATE TABLE `Department` (
  `departmentID` int(11) NOT NULL AUTO_INCREMENT,
  `departmentCode` varchar(45) DEFAULT NULL,
  `departmentName` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`departmentID`),
  UNIQUE KEY `departmentID_UNIQUE` (`departmentID`),
  UNIQUE KEY `departmentCode_UNIQUE` (`departmentCode`)
) ENGINE=InnoDB AUTO_INCREMENT=8529 DEFAULT CHARSET=latin1;
CREATE TABLE `Professor` (
  `professorID` int(11) NOT NULL AUTO_INCREMENT,
  `fName` varchar(45) DEFAULT NULL,
  `lName` varchar(45) DEFAULT NULL,
  `fullName` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`professorID`),
  UNIQUE KEY `professorID_UNIQUE` (`professorID`),
  UNIQUE KEY `fullName_UNIQUE` (`fullName`)
) ENGINE=InnoDB AUTO_INCREMENT=66968 DEFAULT CHARSET=latin1;
CREATE TABLE `Review` (
  `reviewID` int(11) NOT NULL AUTO_INCREMENT,
  `userID` varchar(45) DEFAULT NULL,
  `classID` varchar(45) DEFAULT NULL,
  `professorID` varchar(100) DEFAULT NULL,
  `yearTaken` int(11) DEFAULT NULL,
  `GradeEarned` varchar(2) DEFAULT NULL,
  `reviewBody` tinytext,
  `reviewRating` int(11) DEFAULT NULL,
  PRIMARY KEY (`reviewID`),
  UNIQUE KEY `idnew_table_UNIQUE` (`reviewID`)
) ENGINE=InnoDB AUTO_INCREMENT=19978 DEFAULT CHARSET=latin1;
CREATE TABLE `User` (
  `userID` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(45) DEFAULT NULL,
  `lastName` varchar(45) DEFAULT NULL,
  `gradYear` int(11) DEFAULT NULL,
  `major` varchar(45) DEFAULT NULL,
  `userName` varchar(45) DEFAULT NULL,
  `passWord` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`userID`),
  UNIQUE KEY `userID_UNIQUE` (`userID`),
  UNIQUE KEY `userName_UNIQUE` (`userName`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

