package javaDocs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Review {
	private int reviewID;
	private String userID;
	private String classID;
	private String departmentID;
	public String getDepartmentID() {
		return departmentID;
	}

	public void setDepartmentID(String departmentID) {
		this.departmentID = departmentID;
	}

	private String professorID;
	private String yearTaken;
	private String gradeEarned;
	private String reviewBody;
	private int reviewRating;
	
	public Review(String userID, String classID, String professorID, String yearTaken, String gradeEarned, String reviewBody,
			int reviewRating, Boolean addReviewToDB) {
		this.userID = userID;
		this.classID = classID;
		this.professorID = professorID;
		this.yearTaken = yearTaken;
		this.gradeEarned = gradeEarned;
		this.reviewBody = reviewBody;
		this.reviewRating = reviewRating;
		
		this.departmentID = classID.split("-")[0];
		
		if(addReviewToDB) {
			addToDB(this);
		}
	}

	public String getClassID() {
		return classID;
	}

	public void setClassID(String classID) {
		this.classID = classID;
	}
	public int getReviewID() {
		return reviewID;
	}
	public void setReviewID(int reviewID) {
		this.reviewID = reviewID;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getProfessorID() {
		return professorID;
	}
	public void setProfessorID(String professorID) {
		this.professorID = professorID;
	}
	public String getyearTaken() {
		return yearTaken;
	}
	public void setyearTaken(String yearTaken) {
		this.yearTaken = yearTaken;
	}
	public String getGradeEarned() {
		return gradeEarned;
	}
	public void setGradeEarned(String gradeEarned) {
		this.gradeEarned = gradeEarned;
	}
	public String getReviewBody() {
		return reviewBody;
	}
	public void setReviewBody(String reviewBody) {
		this.reviewBody = reviewBody;
	}
	public int getReviewRating() {
		return reviewRating;
	}
	public void setReviewRating(int reviewRating) {
		this.reviewRating = reviewRating;
	}
	
	public void addToDB(Review r) {
		Connection conn = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String sql = "INSERT INTO Review(userID,professorID, yearTaken, gradeEarned, reviewBody, reviewRating, classID) VALUES(?,?, ?, ?, ?, ?, ?)";
			conn = DriverManager.getConnection("jdbc:mysql://localhost/ClassRankSchema?useLegacyDatetimeCode=false&serverTimezone=UTC&user=root&password=digimons123");
			PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, userID);
			ps.setString(2, professorID);
			ps.setString(3,  yearTaken);
			ps.setString(4, gradeEarned);
			ps.setString(5, reviewBody);
			ps.setString(6,  String.valueOf(reviewRating));
			ps.setString(7, classID);
			
			int rowsInserted = ps.executeUpdate();
			if(rowsInserted > 0) {
				 ResultSet rs = ps.getGeneratedKeys();
				 rs.next();
				 this.reviewID = rs.getInt(1);
				 System.out.println("A new review was inserted successfully!"); 
			}
		} catch(SQLException e) {
			System.out.println("Error adding review to database: " + e.getMessage());
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				if(conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
