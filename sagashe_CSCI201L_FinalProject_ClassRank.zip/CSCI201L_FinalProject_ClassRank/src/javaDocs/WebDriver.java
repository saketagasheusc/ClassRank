package javaDocs;

import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class WebDriver {
	public static ArrayList<Professor> professors;
	public static ArrayList<Course> courses;
	public static ArrayList<Department> departments = new ArrayList<Department>();

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		GetDepartments gd = new GetDepartments("https://web-app.usc.edu/web/soc/api/departments/20191");
		for (Department d : gd.storeDepartments) {
			departments.add(d);
		}
		System.out.println(departments.size());
		ExecutorService executor = Executors.newFixedThreadPool(departments.size());
		for (int i = 0; i < departments.size(); ++i) {
			String url = "https://web-app.usc.edu/web/soc/api/classes/" + departments.get(i).getDepartmentCode()
					+ "/20191";
			GetClasses g = new GetClasses(url);
			GetProfessor p = new GetProfessor(url);
			executor.execute(p);
			executor.execute(g);
		}
		executor.shutdown();
		while (!executor.isTerminated()) {
			Thread.yield();
		}
		System.out.println("Finished! adding courses and professors");
		professors = new ArrayList<Professor>(GetProfessor.professors);
		courses = new ArrayList<Course>(GetClasses.courses);
		String[] grades = { "A+", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D+", "D", "D-", "F" };
		Random rand = new Random();
		int i = -1;
		for (Course c : courses) {
			i++;
			if(i%2 == 0 || i % 3 == 0 || i % 5 == 0) {
				continue;
			}
			else if (c.getDepartment().equalsIgnoreCase("CSCI") || c.getDepartment().equalsIgnoreCase("CTCS")
					|| c.getDepartment().equalsIgnoreCase("BUAD") || c.getDepartment().equalsIgnoreCase("EE")) {
				continue;
			} else {
				Review r = new Review("testUser", c.getCourseCode(),
						professors.get(rand.nextInt(professors.size())).getFullName(),
						Integer.toString((2001 + rand.nextInt(2))), grades[rand.nextInt(grades.length)],
						"This is a test review.", rand.nextInt(6), true);
			}
		}
		System.out.println("Finished!");
	}
}
