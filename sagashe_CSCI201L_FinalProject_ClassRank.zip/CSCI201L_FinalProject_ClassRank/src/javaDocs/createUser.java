package javaDocs;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.*;
//TODO: CHECK IF USER ALREADY EXISTS
@WebServlet("/createUser")
public class createUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
	protected void service (HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		HttpSession session = request.getSession();
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String userName = request.getParameter("userName");
		String passWord = request.getParameter("passWord");
		String major = request.getParameter("major");
		int gradYear = Integer.parseInt(request.getParameter("gradYear"));
		
		System.out.println(firstName+" "+lastName+" "+userName+" "+passWord+" "+major+" "+gradYear);
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String sql = "INSERT INTO User(firstName,lastName,gradYear,major,userName,passWord) VALUES(?,?,?,?,?,?)";
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/ClassRankSchema?useLegacyDatetimeCode=false&serverTimezone=UTC&user=root&password=digimons123");


			PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, firstName);
			ps.setString(2,  lastName);
			ps.setInt(3, gradYear);
			ps.setString(4, major);
			ps.setString(5, userName);
			ps.setString(6,  passWord);
			int userID;
			
			int rowsInserted = ps.executeUpdate();
			if(rowsInserted > 0) {
				 ResultSet rs = ps.getGeneratedKeys();
				 rs.next();
				 userID = rs.getInt(1);
				 System.out.println("A new user was inserted successfully!");
				 User user = new User(userID, firstName, lastName, gradYear, userName, major);
				 session.setAttribute("user", user);
				 user.printInfo();
			}
		} catch(SQLException e) {
			System.out.println("Error adding user to database: " + e.getMessage());
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		response.sendRedirect("OnePage.jsp");
	}
}
