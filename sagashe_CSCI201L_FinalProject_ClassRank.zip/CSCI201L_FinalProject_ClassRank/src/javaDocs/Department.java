package javaDocs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Department {
	private int departmentID;
	public int getDepartmentID() {
		return departmentID;
	}
	public void setDepartmentID(int departmentID) {
		this.departmentID = departmentID;
	}

	private String departmentCode;
	private String departmentName;
	
	public Department(String departmentCode, String departmentName) {
		this.departmentCode = departmentCode;
		this.departmentName = departmentName;
		
		addToDB(this);
	}
	public Department(String departmentCode, String departmentName, Boolean add) {
		this.departmentCode = departmentCode;
		this.departmentName = departmentName;
	}
	public String getDepartmentCode() {
		return departmentCode;
	}
	public void setDepartmentCode(String departmentCode) {
		this.departmentCode = departmentCode;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	
	public void addToDB(Department c) {
		Connection conn = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String sql = "INSERT INTO Department(departmentCode, departmentName) VALUES(?,?)";
			conn = DriverManager.getConnection("jdbc:mysql://localhost/ClassRankSchema?useLegacyDatetimeCode=false&serverTimezone=UTC&user=root&password=digimons123");

			PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, departmentCode);
			ps.setString(2, departmentName);
			
			int rowsInserted = ps.executeUpdate();
			if(rowsInserted > 0) {
				 ResultSet rs = ps.getGeneratedKeys();
				 rs.next();
				 this.departmentID = rs.getInt(1);
				 System.out.println("A new course was inserted successfully!"); 
			}
		} catch(SQLException e) {
			System.out.println("Error adding user to database: " + e.getMessage());
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				if(conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
