package javaDocs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Professor {
	private String fName;
	private String lName;
	private String fullName;
	private int profID;
	
	public Professor(String fName, String lName) {
		this.fName = fName;
		this.lName = lName;
		this.fullName = fName +" "+ lName;
		
		addToDB(this);
	}
	public Professor(String fName, String lName, Boolean add) {
		this.fName = fName;
		this.lName = lName;
		this.fullName = fName +" "+ lName;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public int getProfID() {
		return profID;
	}
	public void setProfID(int profID) {
		this.profID = profID;
	}
	
	public void addToDB(Professor c) {
		Connection conn = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String sql = "INSERT INTO Professor(fName,lName, fullName) VALUES(?,?, ?)";
			conn = DriverManager.getConnection("jdbc:mysql://localhost/ClassRankSchema?useLegacyDatetimeCode=false&serverTimezone=UTC&user=root&password=digimons123");

			PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, fName);
			ps.setString(2, lName);
			ps.setString(3,  fullName);
			
			int rowsInserted = ps.executeUpdate();
			if(rowsInserted > 0) {
				 ResultSet rs = ps.getGeneratedKeys();
				 rs.next();
				 this.profID = rs.getInt(1);
				 System.out.println("A new course was inserted successfully!"); 
			}
		} catch(SQLException e) {
			System.out.println("Error adding user to database: " + e.getMessage());
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
