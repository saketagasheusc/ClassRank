package javaDocs;
import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

//TODO: CHECK IF USER EXISTS, RETURN PASSWORD OR USERNAME INCORRECT
@WebServlet("/validateUser")
public class validateUser extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Connection conn = null;
		Statement ps = null;
		ResultSet rs = null;
		HttpSession session = request.getSession(true);

		String userName = request.getParameter("userName");
		String passWord = request.getParameter("passWord");

		String sqlTotalAuth = "SELECT * FROM User WHERE User.userName = '" + userName + "' AND User.passWord = '"
				+ passWord + "'";
		System.out.println(sqlTotalAuth);

		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost/ClassRankSchema?useLegacyDatetimeCode=false&serverTimezone=UTC&user=root&password=digimons123");
			ps = conn.prepareStatement(sqlTotalAuth, Statement.RETURN_GENERATED_KEYS);

			rs = ps.executeQuery(sqlTotalAuth);
			if (rs.next()) {
				System.out.println("User found");
				int userID = Integer.parseInt(rs.getString("userID"));
				String firstName = rs.getString("firstName");
				String lastName = rs.getString("lastName");
				int gradYear = Integer.parseInt(rs.getString("gradYear"));
				String major = rs.getString("major");
				String username = rs.getString("username");
				User user = new User(userID, firstName, lastName, gradYear, username, major);
				user.printInfo();
				session.setAttribute("user", user);
			}
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		response.sendRedirect("OnePage.jsp");
	}
}