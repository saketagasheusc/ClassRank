package javaDocs;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.HashSet;
import java.util.Vector;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GetDepartments {
	public  HashSet<Department> storeDepartments = new HashSet<Department>();
	public Vector<String> departmentNames = new Vector<String>();

	public GetDepartments(String url) {	
		InputStream is = null;
		try {
			is = new URL(url).openStream();
		} catch (MalformedURLException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		try {
			BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
			String jsonText = readAll(rd);
			JSONObject obj = new JSONObject(jsonText);
			JSONArray obJsonDepartments = (JSONArray) obj.get("department");
			JSONArray obJsonSubDept = null;
			departmentNames = new Vector<String>();
			for(int i = 0; i < obJsonDepartments.length(); i++) {
				JSONObject depObj = obJsonDepartments.getJSONObject(i);
				JSONArray tryArray = null;
				try{
					tryArray = ((JSONArray) depObj.get("department"));
				} catch(JSONException e){
					tryArray = null;
				} catch(ClassCastException e) {
					tryArray = null;
				}
				if(tryArray != null) {
					obJsonSubDept = (JSONArray)depObj.get("department");
					for(int j = 0; j < obJsonSubDept.length(); j++) {
						departmentNames.add(obJsonSubDept.getJSONObject(j).getString("code"));
						System.out.println("Subdep: " + obJsonSubDept.getJSONObject(j).getString("code"));
						String depCode = obJsonSubDept.getJSONObject(j).getString("code");
						String depName = obJsonSubDept.getJSONObject(j).getString("name");
						Department d = new Department(depCode, depName);
						storeDepartments.add(d);
					}
				}
				else {
					departmentNames.add(obJsonDepartments.getJSONObject(i).getString("code"));
					System.out.println("Dep: " + obJsonDepartments.getJSONObject(i).getString("code"));
					String depCode = obJsonDepartments.getJSONObject(i).getString("code");
					String depName = obJsonDepartments.getJSONObject(i).getString("name");
					Department d = new Department(depCode, depName);
					storeDepartments.add(d);
				}
			}	
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	private String readAll(Reader rd) throws IOException {
		StringBuilder sb = new StringBuilder();
		int cp;
		while((cp = rd.read()) != -1) {
			sb.append((char) cp);
		}
		return sb.toString();
	}
}
