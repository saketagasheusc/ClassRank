package javaDocs;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.HashSet;
import java.util.Vector;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GetProfessor extends Thread{
	private String url;
	public static HashSet<Professor> professors = new HashSet<Professor>();

	public GetProfessor(String url) {
		this.url = url;
	}

	public String getUrl() {
		return url;
	}
	
	public static boolean isValid(String url) throws IOException {
		URL ur = new URL(url);
		System.out.println("testing: " + url);
		HttpURLConnection connection = (HttpURLConnection)ur.openConnection();
		connection.setRequestMethod("GET");
		connection.connect();
		
		int code = connection.getResponseCode();
		if(code != 200) {
			System.out.println("Didnt work: " + url);
			return false;
		}
		return true;
		
	}

	public void run() {
		InputStream is = null;
		try {
			if (isValid(url)) {
				try {
					is = new URL(url).openStream();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			else {
				return;
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
			String jsonText = readAll(rd);
			JSONObject obj = new JSONObject(jsonText);
			JSONObject obJsonCourses = (JSONObject) obj.get("OfferedCourses");
			JSONArray obJsonClass = null;
			String lastName;
			String firstName;
			try {
				obJsonClass = (JSONArray) obJsonCourses.get("course");
			} catch (JSONException e) {
				obJsonClass = null;
			} catch (ClassCastException e) {
				obJsonClass = null;
			}
			if (obJsonClass != null) {
				for (int i = 0; i < obJsonClass.length(); i++) {
					lastName = (obJsonClass.optString(i).split("last_name")[1].substring(3).split("\",\"")[0]);
					firstName = (obJsonClass.optString(i).split("last_name")[1].substring(3).split("\",\"")[1]).split("\"}")[0];
					firstName = firstName.substring(13);
					System.out.println(firstName + " " + lastName);
					Professor p = new Professor(firstName, lastName);
					professors.add(p);
					
				}
			} else {
				 System.out.println(obJsonCourses.toString());
//				 courses.add(new Course(PublishedCourseIDS, PublishedCourseName, department));
			}
//			for (int i = 0; i < PublishedCourseID.size(); i++) {
//				System.out.println("Parsed: " + PublishedCourseID.get(i));
//			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private String readAll(Reader rd) throws IOException {
		StringBuilder sb = new StringBuilder();
		int cp;
		while ((cp = rd.read()) != -1) {
			sb.append((char) cp);
		}
		return sb.toString();
	}
	
}
