package javaDocs;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Course {
	private int classID;
	private String courseCode;
	private ArrayList<Integer> Professors;
	private ArrayList<Integer> Reviews;
	private String courseName;
	private String department;
	
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName){
		this.courseName = courseName;
	}
	public int getClassID() {
		return classID;
	}
	public void setClassID(int classID) {
		this.classID = classID;
	}
	public String getCourseCode() {
		return courseCode;
	}
	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}
	public ArrayList<Integer> getProfessors() {
		return Professors;
	}
	public void setProfessors(ArrayList<Integer> professors) {
		Professors = professors;
	}
	public ArrayList<Integer> getReviews() {
		//TODO: Populate array with sql request
		return Reviews;
	}
	public void setReviews(ArrayList<Integer> reviews) {
		Reviews = reviews;
	}
	public void printInfo() {
		System.out.println("courseCode: " + courseCode);
		System.out.println("courseName: " + courseName);
		System.out.println("department: " + department);
	}
	
	public Course(String courseCode, String courseName, String department) {
		this.courseCode = courseCode;
		this.courseName = courseName;
		this.department = department;
		
		addToDB(this);
	}
	public Course(String courseCode, String courseName, String department, Boolean add) {
		this.courseCode = courseCode;
		this.courseName = courseName;
		this.department = department;
	}
	
	public void addToDB(Course c) {
		Connection conn = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String sql = "INSERT INTO Course(Department,ClassCode, CourseName) VALUES(?,?,?)";
			conn = DriverManager.getConnection("jdbc:mysql://localhost/ClassRankSchema?useLegacyDatetimeCode=false&serverTimezone=UTC&user=root&password=digimons123");

			PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, department);
			ps.setString(2, courseCode);
			ps.setString(3, courseName);
			
			int rowsInserted = ps.executeUpdate();
			if(rowsInserted > 0) {
				 ResultSet rs = ps.getGeneratedKeys();
				 rs.next();
				 this.classID = rs.getInt(1);
				 System.out.println("A new course was inserted successfully!"); 
			}
		} catch(SQLException e) {
			System.out.println("Error adding user to database: " + e.getMessage());
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
