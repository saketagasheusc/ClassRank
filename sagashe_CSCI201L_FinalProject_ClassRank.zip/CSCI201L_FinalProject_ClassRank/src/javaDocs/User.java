package javaDocs;

import java.sql.*;
import java.util.*;

import javax.servlet.http.HttpSession;

public class User {
	public HashSet<Review> userReviews;
	public String fullName;
	public int getUserID() {
		return userID;
	}
	public String getFullName() {
		return this.firstName + " " + this.lastName;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getGradDate() {
		return gradDate;
	}

	public void setGradDate(int gradDate) {
		this.gradDate = gradDate;
	}

	public String getuName() {
		return uName;
	}

	public void setuName(String uName) {
		this.uName = uName;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}
	
	public void getUserReviews() {
		this.userReviews.clear();
		Connection conn = null;
		Statement ps = null;
		ResultSet rs = null;
 		try{
	 		String sqlInit = "SELECT * FROM ClassRankSchema.Review WHERE ClassRankSchema.Review.userID = '" + this.uName + "'";
	 		Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost/ClassRankSchema?useLegacyDatetimeCode=false&serverTimezone=UTC&user=root&password=digimons123");
			ps = conn.prepareStatement(sqlInit, Statement.RETURN_GENERATED_KEYS);
			rs = ps.executeQuery(sqlInit);
			while (rs.next()) {
				System.out.println("Review found");
				int reviewID = Integer.parseInt(rs.getString("reviewID"));
				System.out.println("ReviewID: " + reviewID);
				String userID = rs.getString("userID");
				String classID = rs.getString("classID");
				String professorID = rs.getString("professorID");
				String gradYear = rs.getString("yearTaken");
				String gradeEarned = rs.getString("GradeEarned");
				String reviewBody = rs.getString("reviewBody");
				int reviewRating = Integer.parseInt(rs.getString("reviewRating"));
				Review r = new Review(userID, classID, professorID, gradYear, gradeEarned, reviewBody, reviewRating, false);
				userReviews.add(r);
			}
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		
		}
 		for(int i = 0; i < userReviews.size(); i++) {
 			System.out.println("Review found for " + uName);
 		}
	}

	private int userID;
	private String firstName;
	private String lastName;
	private int gradDate;
	private String uName;
	private String major;
	
	public User(int userID, String firstName, String lastName, int gradDate, String uName, String major) {
		this.userReviews = new HashSet<Review>();
		this.userID = userID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gradDate = gradDate;
		this.uName = uName;
		this.major = major;
		this.fullName = firstName + " " + lastName;
	}
	
	public void printInfo() {
		System.out.println("User full name: " + firstName + " " + lastName);
		System.out.println("UserName: " + uName);
		System.out.println("Major: " + major);
		System.out.println("Graduation Year: " + gradDate);
		System.out.println("UserID: " + userID);
	}
	
	
}
