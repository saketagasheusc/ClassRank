package javaDocs;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class AddReview
 */
@WebServlet("/AddReview")
public class AddReview extends HttpServlet {
		private static final long serialVersionUID = 1L;
		
	protected void service (HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		HttpSession session = request.getSession();
		User u = (User) session.getAttribute("user");
		String userID = u.getuName(); //VarChar
		String classID = request.getParameter("courseID"); //VarChar
		String professorID = request.getParameter("profID"); //VarChar
		String GradeEarned = request.getParameter("grade"); //VarChar
		String reviewBody = request.getParameter("comment");
		int reviewRating = Integer.parseInt((request.getParameter("rating")));//Int
		String yearTaken = (request.getParameter("yearTaken")); //Int
		
		System.out.println("USERID: " + userID);
		System.out.println("classID: " + classID);
		System.out.println("professorID: " + professorID);
		System.out.println("GradeEarned: " + GradeEarned);
		System.out.println("reviewBody: " + reviewBody);
		System.out.println("reviewRating: " + reviewRating);
		System.out.println("yearTaken: " + yearTaken);
			
		Review r = new Review(userID, classID, professorID, yearTaken, GradeEarned, reviewBody, reviewRating, true);
		
		response.sendRedirect("OnePage.jsp");
	}
}

